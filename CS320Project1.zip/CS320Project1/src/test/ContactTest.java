/*package test;

import static org.junit.jupiter.api.Assertions.*;

public class ContactTest {
	
	void testContact() {
		Contact Contact = new Contact("123", "Michael", "Jones", "9195555555", "123 Main Street Angier, NC 27501");
		assertTrue(Contact.getcontactId().equals("123"));
		assertTrue(Contact.getfirstName().equals("Michael"));
		assertTrue(Contact.getlastName().equals("Jones"));
		assertTrue(Contact.getphoneNumber().equals("9195555555"));
		assertTrue(Contact.getAddress().equals("123 Main Street Angier, NC 27501"));


		
	}

}
*/